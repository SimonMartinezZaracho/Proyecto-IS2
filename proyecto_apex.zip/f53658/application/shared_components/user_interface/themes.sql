prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 53658
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>24197272370766455362
,p_default_application_id=>53658
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LCIK'
);
wwv_flow_api.create_theme(
 p_id=>wwv_flow_api.id(24394060239759551331)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_api.id(24393953586296551257)
,p_default_dialog_template=>wwv_flow_api.id(24393949269779551255)
,p_error_template=>wwv_flow_api.id(24393941374125551250)
,p_printer_friendly_template=>wwv_flow_api.id(24393953586296551257)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_api.id(24393941374125551250)
,p_default_button_template=>wwv_flow_api.id(24394057370391551318)
,p_default_region_template=>wwv_flow_api.id(24393992291591551280)
,p_default_chart_template=>wwv_flow_api.id(24393992291591551280)
,p_default_form_template=>wwv_flow_api.id(24393992291591551280)
,p_default_reportr_template=>wwv_flow_api.id(24393992291591551280)
,p_default_tabform_template=>wwv_flow_api.id(24393992291591551280)
,p_default_wizard_template=>wwv_flow_api.id(24393992291591551280)
,p_default_menur_template=>wwv_flow_api.id(24394001636328551284)
,p_default_listr_template=>wwv_flow_api.id(24393992291591551280)
,p_default_irr_template=>wwv_flow_api.id(24393990351892551278)
,p_default_report_template=>wwv_flow_api.id(24394022323337551295)
,p_default_label_template=>wwv_flow_api.id(24394054850152551316)
,p_default_menu_template=>wwv_flow_api.id(24394058726180551318)
,p_default_calendar_template=>wwv_flow_api.id(24394058861590551320)
,p_default_list_template=>wwv_flow_api.id(24394038712917551306)
,p_default_nav_list_template=>wwv_flow_api.id(24394050523679551312)
,p_default_top_nav_list_temp=>wwv_flow_api.id(24394050523679551312)
,p_default_side_nav_list_temp=>wwv_flow_api.id(24394045151004551310)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_api.id(24393962298101551264)
,p_default_dialogr_template=>wwv_flow_api.id(24393961272808551264)
,p_default_option_label=>wwv_flow_api.id(24394054850152551316)
,p_default_required_label=>wwv_flow_api.id(24394056144855551317)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_default_navbar_list_template=>wwv_flow_api.id(24394044754517551309)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#IMAGE_PREFIX#themes/theme_42/21.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_api.component_end;
end;
/
