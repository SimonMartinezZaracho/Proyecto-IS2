prompt --application/shared_components/globalization/translations
begin
--   Manifest
--     TRANSLATIONS: 53658
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>24197272370766455362
,p_default_application_id=>53658
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LCIK'
);
null;
wwv_flow_api.component_end;
end;
/
