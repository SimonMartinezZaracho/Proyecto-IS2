prompt --application/shared_components/security/authorizations/admin
begin
--   Manifest
--     SECURITY SCHEME: ADMIN
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>24197272370766455362
,p_default_application_id=>981
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LCIK'
);
wwv_flow_api.create_security_scheme(
 p_id=>wwv_flow_api.id(3030072207611341951)
,p_name=>'ADMIN'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>'SELECT ROLES FROM APEX_USUARIO WHERE ROLES LIKE ''%ADMIN%'' AND USUARIO = :APP_USER'
,p_error_message=>unistr('NO TIENES PERMISOS PARA VER ESTA P\00C1GINA')
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_api.component_end;
end;
/
