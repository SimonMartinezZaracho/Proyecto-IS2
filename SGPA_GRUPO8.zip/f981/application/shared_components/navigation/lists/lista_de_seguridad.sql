prompt --application/shared_components/navigation/lists/lista_de_seguridad
begin
--   Manifest
--     LIST: Lista de seguridad
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>24197272370766455362
,p_default_application_id=>981
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LCIK'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(3019246111158041002)
,p_name=>'Lista de seguridad'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3021747617647141910)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Administraci\00F3n de roles')
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-id-card'
,p_security_scheme=>wwv_flow_api.id(3030072207611341951)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3022280455104187175)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Administraci\00F3n de usuarios')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-circle-o'
,p_security_scheme=>wwv_flow_api.id(3030072207611341951)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
