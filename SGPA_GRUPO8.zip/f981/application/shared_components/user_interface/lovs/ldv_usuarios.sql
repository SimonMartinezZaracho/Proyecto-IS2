prompt --application/shared_components/user_interface/lovs/ldv_usuarios
begin
--   Manifest
--     LDV_USUARIOS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>24197272370766455362
,p_default_application_id=>981
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LCIK'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(5042934413472847079)
,p_lov_name=>'LDV_USUARIOS'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'APEX_USUARIO'
,p_return_column_name=>'ID'
,p_display_column_name=>'USUARIO'
,p_default_sort_column_name=>'USUARIO'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
