prompt --application/shared_components/user_interface/lovs/lovl_proyectos
begin
--   Manifest
--     LOVL_PROYECTOS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>24197272370766455362
,p_default_application_id=>981
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LCIK'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(4707996869866343878)
,p_lov_name=>'LOVL_PROYECTOS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID A,',
'DESCRIPCION B',
'FROM PROYECTOS P'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'A'
,p_display_column_name=>'B'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'B'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
